# Robot-BT
El programa esta organizado en archivos, se crearon clases para hacer el codigo mas facil de entender.

# Diagramas de conexion
![alt tag](https://github.com/TalosElectronics1/Robot-BT/blob/master/Diagramas/Conexion%20BT_bb.png)
![alt tag](https://github.com/TalosElectronics1/Robot-BT/blob/master/Diagramas/Diagrama_PuenteH_Final_bb.png)
